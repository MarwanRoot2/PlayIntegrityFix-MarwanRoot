echo "
             اللهم صّلِ وسَلّمْ عَلۓِ نَبِيْنَامُحَمد ﷺ
╗──────────────────────────────────────╔
                 Telegram : @MarwanRoot                  
╝──────────────────────────────────────╚
"
sleep 2
echo   "⚓ Upgrading 🎗️KeyBox🎗️PIF🎗️Strong🎗️Target🎗️ 🛡️"
ping -w 1 google.com &>/dev/null
if [ $? -ne 0 ]; then
    echo "   مرحبآ انا مروان روت ⛅ الرجاء التأكد من حاله الإنترنت لديك ✂️ "
    sleep 2
    exit 1
fi

# Download Strong File By @MarwanRoot ✅"
        curl -o /data/adb/tricky_store/keybox.xml https://raw.githubusercontent.com/MarwanRoot2/PlayIntegrityFix-MarwanRoot/refs/heads/main/KEY.Marwan
        curl -o /data/adb/pif.json https://raw.githubusercontent.com/MarwanRoot2/PlayIntegrityFix-MarwanRoot/refs/heads/main/pif.json
        curl -o /data/adb/tricky_store/target.txt https://raw.githubusercontent.com/MarwanRoot2/PlayIntegrityFix-MarwanRoot/refs/heads/main/Bootloader
echo
echo
echo
echo " ⭐ سيتم تحويلك تلقائى الى القناة الخاصه بنا 🥇"
sleep 4
echo
echo
echo
echo "      📲 Successfully Updating All Done! 💯"
sleep 1
nohup am start -a android.intent.action.VIEW -d https://t.me/Online_rooting1>/dev/null 2>&1 &
echo
echo
echo "            🇦🇪🇧🇭🇪🇬🇶🇦🇮🇶🇯🇴🇱🇧🇰🇼🇱🇾🇾🇪🇵🇸🇸🇦🇸🇩 "
echo
echo " 🫰 تم صنع الاسكريبت بكل الحب للجميع المشتركين بالقناه ♥ "
sleep_pause